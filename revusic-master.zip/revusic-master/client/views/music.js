Template.music.onCreated(function() {

});

